#include "stm32f10x.h"                  // Device header
#include "Delay.h"
#include "LED.h"
int  main(void)
{
   
    while(1)
	{
   
	}

}
